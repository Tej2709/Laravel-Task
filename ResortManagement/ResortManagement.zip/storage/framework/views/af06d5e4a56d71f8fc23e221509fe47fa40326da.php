

<?php $__env->startSection('content'); ?>

<head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Games In the Resort</h4>
                </div>
                <div class="card-body">

                    <br>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id'));?></th>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name'));?></th>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('description'));?></th>

                                <th>Status</th>
                                <th width="80x">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($games->count()): ?>
                            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($value->name); ?></td>
                                <td><?php echo e($value->description); ?></td>

                                <td><?php echo e($value->status); ?></td>
                                <td>
                                    <a href="<?php echo e(route('checkin.index')); ?>" class="btn btn-warning btn-sm">Play</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>
    <br>
    <a href="<?php echo e(route('home')); ?>" class="btn btn-danger btn-sm">Back</a>
    <br>
    <br>
    <?php echo $games->appends(\Request::except('page'))->render(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ResortManagement\resources\views/checkin/index.blade.php ENDPATH**/ ?>