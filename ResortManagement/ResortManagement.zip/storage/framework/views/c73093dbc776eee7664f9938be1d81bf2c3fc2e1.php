
<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
<script>
    
         $(document).ready(function() {
            $("#usercreateform").validate({
                rules: {
                    name: {
                        required: true,
                        minlength:4,
                        maxlength: 20,
                    },
                    email:{
                        required: true,
                        email:true,
                        maxlength:30,

                    },

                    password:{
                            required: true,
                            minlength:5,
                            maxlength:20,
                    },
                },

                messages: {
                    name: {
                        required: "Categoryname  is required",
                        minlength:"Categoryname must be at least 4 characters",
                        maxlength: "Name  be more than 20 characters"
                    },

                    email: {
                        required: "Email is required",
                        email: "Email must be a valid email address",
                        maxlength: "Email cannot be more than 30 characters",
                    },

                    password: {
                        required: "Password is required",
                        minlength: "Password must be at least 5 characters"
                    },


                   
                }
            });
        });
    </script>
     <style>
    label.error {
         color: #dc3545;
         font-size: 14px;
    }
</style>
</head>
<?php $__env->startSection('content'); ?>

<div class="container">

    <form action="<?php echo e(route('users.store')); ?>" enctype="multipart/form-data" method="Post" id="usercreateform">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <!--Html Input for name-->

        <div class="form-group">
            <label for="Name">Username:</label>
            <input type="text" class="form-control" name="name" id="name" placeholder="Please enter name" value="<?php echo e(old('name')); ?>">
        </div>
        <?php if($errors->has('name')): ?>
        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
        <?php endif; ?>
        <br>
        <!--Html Input for email-->

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Please enter email address" value="<?php echo e(old('email')); ?>" name="email">
        </div>
        <?php if($errors->has('email')): ?>
        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
        <?php endif; ?>
        <br>

        <!--Html Input for password-->

        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Please enter password" value="<?php echo e(old('password')); ?>">
        </div>
        <?php if($errors->has('password')): ?>
        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
        <?php endif; ?>
        <br>

        <button type="submit" class="btn btn-primary">Create</button>
        <a class="btn btn-danger" href="<?php echo e(route('users.index')); ?>">Back</a>
    </form>


</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ResortManagement\resources\views/users/create.blade.php ENDPATH**/ ?>