

<head>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#resortcreateform").validate({
                rules: {
                    name: {
                        required: true,
                        minlength: 4,
                        maxlength: 20,
                    },
                    description: {
                        required: true,

                        maxlength: 100,

                    },

                 
                    status: {
                        required: true,
                    },
                },

                messages: {
                    name: {
                        required: "Categoryname  is required",
                        minlength: "Categoryname must be at least 4 characters",
                        maxlength: "Name  be more than 20 characters"
                    },

                    description: {
                        required: "Description is required",

                        maxlength: "Description cannot be more than 100 characters",
                    },
                }
            });
        });
    </script>
    <style>
        label.error {
            color: #dc3545;
            font-size: 14px;
        }
    </style>
</head>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">

            <?php if(session('status')): ?>
            <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h4>Update Resort Information</h4>
                </div>
                <div class="card-body">

                    <form action="<?php echo e(route('resorts.update',$resort->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="Name">Resort Name:</label>
                            <input type="text" class="form-control" id="name" placeholder="Please enter resort name" name="name" value="<?php echo e($resort->name); ?>">
                        </div>
                        <?php if($errors->has('name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                        <br>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <input type="text" class="form-control" id="description" placeholder="Please enter resort description" " name=" description" value="<?php echo e($resort->description); ?>">
                        </div>
                        <?php if($errors->has('description')): ?>
                        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                        <?php endif; ?>
                        <br>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <label for="Smallimage">Small Image</label>
                                <input type="file" name="image" class="form-control" id="image" placeholder="image...">
                            </div>
                            <?php if($errors->has('image')): ?>
                            <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                            <?php endif; ?>
                        </div>
                        <br>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <label for="Bigimage">Big Image</label>
                                <input type="file" name="bigimage" class="form-control" id="bigimage" placeholder="image...">
                            </div>
                            <?php if($errors->has('bigimage')): ?>
                            <span class="text-danger"><?php echo e($errors->first('bigimage')); ?></span>
                            <?php endif; ?>
                            <br>
                        </div>
                        <br>

                        <div class="form-group">

                            <input type="radio" name="status" value="Active" <?php echo e(($resort->status=="Active")? "checked" : ""); ?>>Active
                            <input type="radio" name="status" value="Inactive" <?php echo e($resort->status=="Inactive"? "checked" : ""); ?>>Inactive
                        </div>


                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-danger float-end">BACK</a>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ResortManagement\resources\views/resorts/edit.blade.php ENDPATH**/ ?>