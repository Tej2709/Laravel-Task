

<?php $__env->startSection('content'); ?>

<head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Resort List</h4>
                    <a class="btn btn-primary" href="<?php echo e(route('users.index')); ?>">Users</a>
                    <a class="btn btn-warning" href="<?php echo e(route('games.index')); ?>">Game</a>
                    <?php if(auth()->user()->usertype=="1"): ?>
                    <a class="btn btn-info" href="<?php echo e(route('resort.export')); ?>">Export Data</a>
                    <?php endif; ?>

                </div>
                <div class="card-body">

                    <div class="form-group">
                        <?php if(auth()->user()->usertype=="1"): ?>
                        <a class="btn btn-success" href="<?php echo e(route('resorts.create')); ?>">Create New Resort</a>
                        <?php endif; ?>
                        <br>

                    </div>
                    <br>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="70px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id'));?></th>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name'));?></th>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('description'));?></th>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('image'));?></th>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('bigimage'));?></th>
                                <th width="80px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('status'));?></th>
                                <?php if(auth()->user()->usertype=="1"): ?>
                                <th width="150px">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($resort->count()): ?>
                            <?php $__currentLoopData = $resort; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($value->name); ?></td>
                                <td><?php echo e($value->description); ?></td>
                                <td>
                                    <img src="<?php echo e(asset('public/images/'. $value->image)); ?>" width="70px" height="70px" alt="image">
                                </td>
                                <td>
                                    <img src="<?php echo e(asset('public/image/'. $value->bigimage)); ?>" width="80px" height="80px" alt="Image">
                                </td>

                                <td><?php echo e($value->status); ?></td>
                                <?php if(auth()->user()->usertype=="1"): ?>
                                <td>
                                    <form action="<?php echo e(route('resorts.destroy', $value->id)); ?>" method="post">
                                        <a href="<?php echo e(route('resorts.edit', $value->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm" type="submit" onclick="return confirm('Are you sure you want to delete this resort?')">Delete</button>
                                    </form>
                                </td>
                                <?php endif; ?>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>
    <br>
    <?php echo $resort->appends(\Request::except('page'))->render(); ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ResortManagement\resources\views/resorts/index.blade.php ENDPATH**/ ?>