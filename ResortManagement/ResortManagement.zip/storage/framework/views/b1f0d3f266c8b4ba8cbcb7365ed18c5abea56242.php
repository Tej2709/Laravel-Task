

<?php $__env->startSection('content'); ?>
<head>
   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<div class="container">

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>User List</h4>
                    <a href="<?php echo e(route('resorts.index')); ?>" class="btn btn-primary">Resorts</a>
                    <a href="<?php echo e(route('games.index')); ?>" class="btn btn-warning">Games</a>
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-info">Home</a>

                    
                </div>
                <div class="card-body">
                    <?php if(auth()->user()->usertype=="1"): ?>
                    <div class="form-group">
                        <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>">Create New User</a>
                    </div>
                    <?php endif; ?>
                    <br>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id'));?></th>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name'));?></th>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('email'));?></th>
                                <?php if(auth()->user()->usertype=="1"): ?>
                                <th width="150px">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if($data->count()): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($value->name); ?></td>
                                <td><?php echo e($value->email); ?></td>
                                <?php if(auth()->user()->usertype=="1"): ?>
                                <td>
                                    <form action="<?php echo e(route('users.destroy', $value->id)); ?>" method="post">
                                        <a href="<?php echo e(route('users.edit', $value->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm" type="submit" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                                    </form>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
    <br>
    <?php echo $data->appends(\Request::except('page'))->render(); ?>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ResortManagement\resources\views/users/index.blade.php ENDPATH**/ ?>