

<head>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#gameseditform").validate({
                rules: {
                    name: {
                        required: true,
                        minlength: 4,
                        maxlength: 20,
                    },
                    description: {
                        required: true,

                        maxlength: 250,

                    },

                    resorts: {
                        required: true,
                    },
                    status: {
                        required: true,
                    },
                },

                messages: {
                    name: {
                        required: "Categoryname  is required",
                        minlength: "Categoryname must be at least 4 characters",
                        maxlength: "Name  be more than 20 characters"
                    },

                    description: {
                        required: "Description is required",

                        maxlength: "Description cannot be more than 250 characters",
                    },
                }
            });
        });
    </script>
    <style>
        label.error {
            color: #dc3545;
            font-size: 14px;
        }
    </style>
</head>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">

            <?php if(session('status')): ?>
            <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h4>Update Game</h4>
                </div>
                <div class="card-body">

                    <form action="<?php echo e(route('games.update',$data->id)); ?>" method="POST" enctype="multipart/form-data" id="gameseditform">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="Name">Game Name:</label>
                            <input type="text" class="form-control" id="name" placeholder="Please enter game name" name="name" value="<?php echo e($data->name); ?>">
                        </div>
                        <?php if($errors->has('name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                        <br>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <input type="text" class="form-control" id="description" placeholder="Please enter game description" " name=" description" value="<?php echo e($data->description); ?>">
                        </div>
                        <?php if($errors->has('description')): ?>
                        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                        <?php endif; ?>
                        <br>
                        <div class="form-group">
                            <label for="resorts">Resorts:</label>
                            <select class="form-control" name="resorts">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>" <?php echo e($value->id=="$data->resorts"? "selected" : ""); ?>><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <br>

                        <div class="form-group">

                            <input type="radio" name="status" value="Active" <?php echo e(($data->status=="Active")? "checked" : ""); ?>>Active
                            <input type="radio" name="status" value="Inactive" <?php echo e($data->status=="Inactive"? "checked" : ""); ?>>Inactive
                        </div>
                        <br>


                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="<?php echo e(route('games.index')); ?>" class="btn btn-danger float-end">BACK</a>
                        </div>
                     

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ResortManagement\resources\views/games/edit.blade.php ENDPATH**/ ?>