

<?php $__env->startSection('content'); ?>

<head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Games List</h4>
                    <a class="btn btn-primary" href="<?php echo e(route('users.index')); ?>">Users</a>
                    <a class="btn btn-warning" href="<?php echo e(route('resorts.index')); ?>">Resorts</a>

                    <select id="gamesfilter" name="gamesfilter">
                        <option value="">Select Resort</option>

                    </select>
                </div>
                <div class="card-body">


                    <div class="form-group">
                        <?php if(auth()->user()->usertype=="1"): ?>
                        <a class="btn btn-success" href="<?php echo e(route('games.create')); ?>">Create New Game</a>
                        <?php endif; ?>
                        <br>

                    </div>




                    <br>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="100px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id'));?></th>
                                <th width="100px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name'));?></th>
                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('description'));?></th>

                                <th width="150px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('resorts'));?></th>
                                <th width="80px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('status'));?></th>
                                <?php if(auth()->user()->usertype=="1"): ?>
                                <th width="150px">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($games->count()): ?>
                            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($value->name); ?></td>
                                <td><?php echo e($value->description); ?></td>


                                <td><?php echo e($value->rname); ?></td>
                                <td><?php echo e($value->status); ?></td>
                                <?php if(auth()->user()->usertype=="1"): ?>
                                <td>
                                    <form action="<?php echo e(route('games.destroy', $value->id)); ?>" method="post">
                                        <a href="<?php echo e(route('games.edit', $value->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm" type="submit" onclick="return confirm('Are you sure you want to delete this game?')">Delete</button>
                                    </form>
                                </td>
                                <?php endif; ?>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>


                </div>

            </div>

        </div>

    </div>
    <br>
    <?php echo $games->appends(\Request::except('page'))->render(); ?>

</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ResortManagement\resources\views/games/index.blade.php ENDPATH**/ ?>